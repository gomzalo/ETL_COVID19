use dbss2g21;
truncate table caso;
delete from departamento;
delete from doctor;
delete from error;
delete from fecha;
delete from hospital;
delete from paciente;
delete from region;